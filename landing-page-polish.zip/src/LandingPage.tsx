/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { motion } from 'motion/react';
import {
  Terminal,
  ShieldCheck,
  Zap,
  Send,
  BrainCircuit,
  ArrowUpRight,
  Eye,
  ChevronRight,
  Github,
  ExternalLink,
  Lock,
} from 'lucide-react';
import { CONTRACT_ADDRESS, AUTHORIZED_AUDITOR, SEPOLIA_CHAIN_ID } from './lib/contract';

interface LandingPageProps {
  /** Fired when "Launch Terminal" is clicked — parent should mount the ConnectionGate next. */
  onLaunch: () => void;
  /** Fired when "Enter as Guest" is clicked — skips the wallet handshake entirely, straight to View-Only dashboard. */
  onGuestMode: () => void;
}

const TRINITY = [
  {
    icon: BrainCircuit,
    title: 'Alpha Hunter',
    tag: 'LLM',
    body: 'Narrative Synthesis & Sentiment Scoring. Real-time extraction of high-conviction signals from the SoSoValue News Feed.',
  },
  {
    icon: ShieldCheck,
    title: 'Risk Auditor',
    tag: 'Python',
    body: 'The Finality Gate. Mandatory VETO rules based on ETF Net Inflows and mathematical Position Sizing (Half-Kelly).',
  },
  {
    icon: Send,
    title: 'Sentinel Mobility',
    tag: 'Telegram',
    body: '24/7 Global Oversight. Full-duplex Telegram integration for mobile alerts and on-chain trade execution.',
  },
];

const SOCIAL_LINKS = [
  { icon: Github, label: 'GitHub', href: 'https://github.com/dollaryusuf/core-intelligence' },
  { icon: Send, label: 'Telegram', href: 'https://t.me/' }, // TODO: replace with the live Sentinel bot/channel link
  { icon: ExternalLink, label: 'Etherscan', href: `https://sepolia.etherscan.io/address/${CONTRACT_ADDRESS}` },
];

export function LandingPage({ onLaunch, onGuestMode }: LandingPageProps) {
  return (
    <motion.div
      key="landing-page"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ y: -60, opacity: 0 }}
      transition={{ duration: 0.6, ease: 'easeInOut' }}
      className="fixed inset-0 z-40 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-900 via-black to-black overflow-y-auto"
    >
      {/* Ambient backdrop — lightweight CSS gradients + grid, no heavy assets */}
      <div className="absolute inset-0 grid-bg opacity-30 pointer-events-none" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[500px] bg-emerald-500/10 blur-[140px] rounded-full pointer-events-none" />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/60 pointer-events-none" />
      {/* Scanner sweep — reinforces the "live financial system" feel */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-emerald-400/70 to-transparent animate-scanner pointer-events-none" />

      <div className="relative z-10 min-h-full flex flex-col">
        {/* Top bar / logo */}
        <div className="max-w-6xl w-full mx-auto px-6 pt-8 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/30 grid place-items-center">
            <Terminal size={16} className="text-emerald-500" />
          </div>
          <span className="text-white font-bold text-sm tracking-tight">
            SoSo-Vault <span className="text-emerald-500 font-mono">/</span> Core Intelligence
          </span>
        </div>

        {/* Hero — vertically centered, px-6 so nothing touches the screen edge on mobile */}
        <div className="max-w-4xl w-full mx-auto px-6 pt-20 pb-16 text-center flex-1 flex flex-col items-center justify-center">
          <motion.span
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-[10px] font-mono font-bold uppercase tracking-[0.3em] text-emerald-500/70 border border-emerald-500/20 bg-emerald-500/5 px-3 py-1 rounded-full mb-6"
          >
            ● Ethereum Sepolia &middot; Institutional Wave 2
          </motion.span>

          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.05 }}
            className="text-3xl sm:text-5xl font-bold tracking-tight text-white leading-[1.1] font-sans"
          >
            SOSO-VAULT: <span className="text-emerald-500">NEURAL CONSENSUS PROTOCOL</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.15 }}
            className="mt-5 text-sm sm:text-base text-slate-400 max-w-2xl leading-relaxed"
          >
            Autonomous Treasury Intelligence for the Solo-Operator. Bridging SoSoValue Institutional
            Data with Hard-Coded Quant Governance.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.25 }}
            className="mt-10 flex flex-col items-center gap-4"
          >
            <button
              onClick={onLaunch}
              className={[
                'relative px-10 py-5 rounded-2xl font-bold uppercase tracking-widest text-sm font-mono',
                'bg-emerald-500 text-black hover:bg-emerald-400 transition-all',
                'shadow-[0_0_20px_rgba(16,185,129,0.2)] hover:shadow-[0_0_35px_rgba(16,185,129,0.35)]',
                'flex items-center gap-3',
              ].join(' ')}
            >
              <ShieldCheck size={18} className="relative z-10" />
              <span className="relative z-10">Launch Terminal</span>
              <ChevronRight size={18} className="relative z-10" />
            </button>

            {/* Security Verified badge — reinforces the settlement layer before the user even connects */}
            <div className="flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-widest text-emerald-500/60">
              <Lock size={11} />
              Security Verified &middot; Ethereum Sepolia Settlement Layer
            </div>

            <button
              onClick={onGuestMode}
              className="mt-2 flex items-center gap-1.5 text-[11px] font-mono text-slate-500 hover:text-white underline underline-offset-4 decoration-slate-600 hover:decoration-white/50 transition-colors"
            >
              <Eye size={12} />
              Enter as Guest (View-Only Mode)
            </button>
          </motion.div>
        </div>

        {/* Trinity Feature Grid — glass-morphism cards */}
        <div className="max-w-6xl w-full mx-auto px-6 pb-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {TRINITY.map((h, i) => (
              <motion.div
                key={h.title}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 + i * 0.1 }}
                className="p-6 rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur-md hover:border-emerald-500/30 transition-colors"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 grid place-items-center">
                    <h.icon size={18} className="text-emerald-500" />
                  </div>
                  <span className="text-[9px] font-mono uppercase tracking-widest text-slate-500 border border-white/10 rounded-full px-2 py-0.5">
                    {h.tag}
                  </span>
                </div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wide mb-2 font-sans">{h.title}</h3>
                <p className="text-[12px] text-slate-400 leading-relaxed">{h.body}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Social Proof + Governance Footer */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="border-t border-white/10 bg-black/40"
        >
          {/* Stats + social icons */}
          <div className="max-w-6xl w-full mx-auto px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-white/5">
            <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[11px] font-mono text-slate-400">
              <span>AUM: <span className="text-emerald-400">$142.5M</span></span>
              <span className="text-slate-700">|</span>
              <span>Alpha Capture: <span className="text-emerald-400">17.0%</span></span>
              <span className="text-slate-700">|</span>
              <span>Settlement: <span className="text-emerald-400">ETH Sepolia</span></span>
            </div>
            <div className="flex items-center gap-3">
              {SOCIAL_LINKS.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={s.label}
                  className="w-8 h-8 rounded-lg border border-white/10 grid place-items-center text-slate-500 hover:text-emerald-400 hover:border-emerald-500/30 transition-colors"
                >
                  <s.icon size={14} />
                </a>
              ))}
            </div>
          </div>

          {/* Governance / on-chain addresses */}
          <div className="max-w-6xl w-full mx-auto px-6 py-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-[10px] font-mono">
            <div className="flex items-center gap-2 text-slate-500 uppercase tracking-widest">
              <ShieldCheck size={12} className="text-emerald-500/70" />
              Governance &middot; Ethereum Sepolia (Chain {SEPOLIA_CHAIN_ID})
            </div>
            <div className="flex flex-wrap items-center gap-x-8 gap-y-2">
              <div className="flex items-center gap-2">
                <span className="text-slate-500 uppercase tracking-widest">Auditor Wallet</span>
                <a
                  href={`https://sepolia.etherscan.io/address/${AUTHORIZED_AUDITOR}`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-emerald-400 hover:underline flex items-center gap-1"
                >
                  {AUTHORIZED_AUDITOR.slice(0, 6)}...{AUTHORIZED_AUDITOR.slice(-4)}
                  <ArrowUpRight size={9} />
                </a>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-slate-500 uppercase tracking-widest">Execution Contract</span>
                <a
                  href={`https://sepolia.etherscan.io/address/${CONTRACT_ADDRESS}`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-emerald-400 hover:underline flex items-center gap-1"
                >
                  {CONTRACT_ADDRESS.slice(0, 6)}...{CONTRACT_ADDRESS.slice(-4)}
                  <ArrowUpRight size={9} />
                </a>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
