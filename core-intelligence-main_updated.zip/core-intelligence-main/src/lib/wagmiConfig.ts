/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Wagmi configuration for the Institutional Handshake / on-chain execution layer.
 *
 * Chain: Ethereum Sepolia Testnet ONLY. This app never targets mainnet — every
 * execution path (ConnectionGate, useExecuteNeuralSignal, Etherscan links) is
 * hard-wired to Sepolia so there is zero risk of a real-fund transaction.
 *
 * Connector: `injected()` covers MetaMask and any other EIP-1193 browser wallet
 * without pulling in WalletConnect's cloud project-id requirement, which keeps
 * the "Auditor Vault" handshake a single click for judges.
 */
import { http, createConfig } from 'wagmi';
import { sepolia } from 'wagmi/chains';
import { injected } from 'wagmi/connectors';

// Optional dedicated RPC (Alchemy/Infura/etc). Falls back to the public
// Sepolia RPC baked into wagmi/viem if not provided.
const SEPOLIA_RPC_URL = import.meta.env.VITE_SEPOLIA_RPC_URL as string | undefined;

export const wagmiConfig = createConfig({
  chains: [sepolia],
  connectors: [injected()],
  transports: {
    [sepolia.id]: SEPOLIA_RPC_URL ? http(SEPOLIA_RPC_URL) : http(),
  },
});

declare module 'wagmi' {
  interface Register {
    config: typeof wagmiConfig;
  }
}
