/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Terminal, ShieldCheck, Loader2, ChevronRight, CheckCircle2 } from 'lucide-react';
import { cn } from '../lib/utils';

interface BootLogSpec {
  id: string;
  text: string;
  /** ms after the previous line before this line appears */
  delay: number;
}

interface SplashScreenProps {
  /**
   * Called once the fade-out animation finishes. Parent should stop
   * rendering <SplashScreen /> (or hide it) at this point.
   */
  onComplete: () => void;
  /**
   * Shared-promise gatekeeper flag, lifted from App.tsx. This mirrors the same
   * `intelligenceLoading` state that governs the Dashboard, so the SplashScreen
   * never has to fetch anything itself — it just reflects whether the single,
   * shared `fetchIntelligence()` call in App.tsx has resolved yet. The
   * "Proceed to Terminal" button cannot enable while this is true, guaranteeing
   * the dashboard behind the splash is already fully populated when revealed.
   */
  isLoading: boolean;
  /** Minimum time (ms) the boot sequence stays on screen, even if the fetch is instant. Default 3500ms. */
  minDurationMs?: number;
  /**
   * Fired the instant the user clicks "Proceed to Terminal", before the fade-out
   * animation plays. Lets the parent mount whatever comes next (e.g. the
   * ConnectionGate) underneath the splash so the two crossfade instead of
   * hard-cutting once the splash fully unmounts.
   */
  onExitStart?: () => void;
}

// Staggered so the user's eyes can track "Technical Progress": line 1 appears
// immediately, then each subsequent line lands 800ms after the previous one
// (0ms, 800ms, 1600ms, 2400ms, 3200ms cumulative).
const BOOT_LOGS: BootLogSpec[] = [
  { id: 'init', text: 'Initializing Core Intelligence Node-001...', delay: 0 },
  { id: 'sosovalue', text: 'Connecting to SoSoValue API (ETF Flows / Sentiment)...', delay: 800 },
  { id: 'auditor', text: 'Verifying EVM Auditor Handshake (0x42f...E921)...', delay: 800 },
  { id: 'risk', text: 'Loading Python Risk Auditor Ruleset (Hard-Coded Guardrails)...', delay: 800 },
  { id: 'consensus', text: 'Establishing Neural Consensus Link...', delay: 800 },
];

export function SplashScreen({ onComplete, isLoading, minDurationMs = 3500, onExitStart }: SplashScreenProps) {
  const [visibleCount, setVisibleCount] = useState(0);
  const [minTimeElapsed, setMinTimeElapsed] = useState(false);
  const [exiting, setExiting] = useState(false);
  const hasBooted = useRef(false);

  // `dataReady` mirrors the shared `intelligenceLoading` state owned by App.tsx —
  // no fetch happens in this component anymore, it just reflects the one fetch
  // that App.tsx already kicked off.
  const dataReady = !isLoading;

  // Reveal boot log lines sequentially
  useEffect(() => {
    if (hasBooted.current) return;
    hasBooted.current = true;

    let elapsed = 0;
    const timers: ReturnType<typeof setTimeout>[] = [];
    BOOT_LOGS.forEach((step, i) => {
      elapsed += step.delay;
      timers.push(setTimeout(() => setVisibleCount(i + 1), elapsed));
    });

    // Enforce a minimum boot duration so the sequence never feels like a flash
    const minTimer = setTimeout(() => setMinTimeElapsed(true), minDurationMs);
    timers.push(minTimer);

    return () => timers.forEach(clearTimeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const bootComplete = visibleCount >= BOOT_LOGS.length;
  // Gatekeeper: the "Proceed to Terminal" button only enables once the boot log
  // animation has finished, the shared fetch has resolved (dataReady), and the
  // minimum boot duration has elapsed.
  const canConnect = bootComplete && dataReady && minTimeElapsed;

  const handleConnect = () => {
    onExitStart?.();
    setExiting(true);
  };

  return (
    <AnimatePresence onExitComplete={onComplete}>
      {!exiting && (
        <motion.div
          key="splash"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.02, filter: 'blur(6px)' }}
          transition={{ duration: 0.6, ease: 'easeInOut' }}
          className="fixed inset-0 z-50 bg-black flex items-center justify-center overflow-hidden"
        >
          {/* Ambient grid + glow backdrop */}
          <div className="absolute inset-0 grid-bg opacity-40" />
          <div className="absolute top-1/2 left-1/2 w-[600px] h-[600px] -translate-x-1/2 -translate-y-1/2 bg-emerald-500/5 blur-[120px] rounded-full" />

          {/* Connection indicator — pulses while the shared fetch is in flight,
              flips to a solid green checkmark the instant data is ready. This
              proves the vault is "live-wired" even while the boot logs are
              still finishing their staggered animation. */}
          <div className="absolute top-6 right-6 z-20 flex items-center gap-1.5">
            <span className="text-[9px] font-mono uppercase tracking-widest text-emerald-500/50">
              {dataReady ? 'Live-Wired' : 'Connecting'}
            </span>
            {dataReady ? (
              <CheckCircle2 size={14} className="text-emerald-400" />
            ) : (
              <span className="relative flex h-3 w-3">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-75" />
                <span className="relative inline-flex h-3 w-3 rounded-full bg-emerald-500" />
              </span>
            )}
          </div>

          <div className="relative z-10 w-full max-w-md px-8">
            {/* Logo / Mark */}
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="flex items-center gap-3 mb-8"
            >
              <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 grid place-items-center">
                <Terminal size={18} className="text-emerald-500" />
              </div>
              <div>
                <h1 className="text-white font-bold tracking-tight text-sm">
                  SoSo-Vault <span className="text-emerald-500 font-mono">/</span> Core Intelligence
                </h1>
                <p className="text-[9px] uppercase tracking-[0.25em] text-emerald-500/50 font-mono">
                  Institutional Boot Sequence
                </p>
              </div>
            </motion.div>

            {/* System Status Logs */}
            <div className="font-mono text-[11px] space-y-2.5 min-h-[150px]">
              <AnimatePresence>
                {BOOT_LOGS.slice(0, visibleCount).map((step, i) => {
                  const isLatest = i === visibleCount - 1 && !bootComplete;
                  return (
                    <motion.div
                      key={step.id}
                      initial={{ opacity: 0, x: -6 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.35 }}
                      className="flex items-center gap-2"
                    >
                      <span className="text-emerald-500/40 shrink-0">[{String(i + 1).padStart(2, '0')}]</span>
                      <span className="text-emerald-500 flex-1 truncate">{step.text}</span>
                      {isLatest ? (
                        <Loader2 size={11} className="text-emerald-500/70 animate-spin shrink-0" />
                      ) : (
                        <span className="text-emerald-500/70 font-bold shrink-0">[OK]</span>
                      )}
                    </motion.div>
                  );
                })}
              </AnimatePresence>

              {bootComplete && !dataReady && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex items-center gap-2 pt-1 text-emerald-500/60"
                >
                  <Loader2 size={11} className="animate-spin shrink-0" />
                  <span>Awaiting SoSoValue payload confirmation...</span>
                </motion.div>
              )}
            </div>

            {/* Progress bar */}
            <div className="mt-6 h-1 bg-emerald-500/10 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${(visibleCount / BOOT_LOGS.length) * 100}%` }}
                transition={{ ease: 'easeOut' }}
                className="h-full bg-emerald-500"
              />
            </div>

            {/* Proceed to Terminal button — disabled/hidden until the shared
                intelligence fetch has resolved (canConnect === dataReady && ...) */}
            <div className="mt-8 h-14">
              <AnimatePresence>
                {canConnect && (
                  <motion.button
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -6 }}
                    onClick={handleConnect}
                    className={cn(
                      "w-full py-4 rounded-xl bg-emerald-500 text-black font-bold uppercase tracking-widest text-[11px] font-mono",
                      "flex items-center justify-center gap-2 transition-all hover:bg-emerald-400",
                      "shadow-[0_0_25px_rgba(16,185,129,0.35)]"
                    )}
                  >
                    <ShieldCheck size={14} />
                    Proceed to Terminal
                    <ChevronRight size={14} />
                  </motion.button>
                )}
              </AnimatePresence>
            </div>

            <p className="text-center text-[9px] uppercase tracking-[0.2em] text-emerald-500/30 font-mono">
              Neural Consensus &middot; Zero Discretion &middot; Verified On-Chain
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
